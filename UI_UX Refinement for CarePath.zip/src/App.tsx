import { useEffect, useRef, useState, type ReactNode } from "react";

type Screen = "home" | "intro" | "assessment" | "loading" | "result" | "care";
type IconName =
  | "arrow"
  | "back"
  | "check"
  | "chevron"
  | "clock"
  | "close"
  | "heart"
  | "location"
  | "menu"
  | "phone"
  | "search"
  | "share"
  | "shield"
  | "spark"
  | "video";

const questions = [
  {
    eyebrow: "First, let’s understand what’s happening",
    title: "What best describes how you’re feeling?",
    helper: "Choose the closest match. You can add context later.",
    options: [
      { label: "A new symptom or concern", detail: "Something started recently", icon: "spark" },
      { label: "An ongoing health issue", detail: "Something persistent or recurring", icon: "clock" },
      { label: "A change in my mental wellbeing", detail: "Stress, mood, sleep, or anxiety", icon: "heart" },
      { label: "I’m not sure yet", detail: "Help me work out where to begin", icon: "shield" },
    ],
  },
  {
    eyebrow: "A little more context",
    title: "How much is this affecting your day?",
    helper: "Think about sleep, work, movement, and your usual routines.",
    options: [
      { label: "A little", detail: "I can mostly continue as normal", icon: "spark" },
      { label: "Quite a bit", detail: "It’s making everyday things harder", icon: "clock" },
      { label: "A lot", detail: "I’m struggling with normal activities", icon: "heart" },
      { label: "It changes day to day", detail: "The impact isn’t consistent", icon: "shield" },
    ],
  },
  {
    eyebrow: "Timing helps us guide you",
    title: "How long has this been going on?",
    helper: "An estimate is completely fine.",
    options: [
      { label: "Today", detail: "It started in the last 24 hours", icon: "spark" },
      { label: "A few days", detail: "Less than a week", icon: "clock" },
      { label: "A few weeks or more", detail: "It’s been ongoing", icon: "heart" },
      { label: "I’m not sure", detail: "The timing is hard to pinpoint", icon: "shield" },
    ],
  },
  {
    eyebrow: "One last safety check",
    title: "Do you need help right now?",
    helper: "This helps us put urgent support first when it matters.",
    options: [
      { label: "No, I feel safe right now", detail: "I can take time to consider my options", icon: "check" },
      { label: "I’m worried it may be urgent", detail: "I’d like guidance as soon as possible", icon: "clock" },
      { label: "I’m in immediate danger", detail: "Show emergency support now", icon: "shield" },
    ],
  },
] as const;

const providers = [
  {
    name: "Riverside Community Health",
    type: "Primary care clinic",
    meta: "0.8 miles · Next opening today, 3:40 PM",
    tags: ["In person", "Same-day"],
    initials: "RC",
    tone: "teal",
  },
  {
    name: "Harbor Health Online",
    type: "Virtual care",
    meta: "Available in about 12 minutes",
    tags: ["Video visit", "Open now"],
    initials: "HH",
    tone: "blue",
  },
  {
    name: "Northside Walk-in Clinic",
    type: "Urgent care clinic",
    meta: "1.6 miles · Usually a 25–40 min wait",
    tags: ["In person", "Walk-in"],
    initials: "NW",
    tone: "sand",
  },
];

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    arrow: <path d="M5 12h14M13 6l6 6-6 6" />,
    back: <path d="m15 18-6-6 6-6" />,
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    clock: (
      <>
        <circle cx="12" cy="12" r="8.5" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    close: <path d="m6 6 12 12M18 6 6 18" />,
    heart: <path d="M20.8 9.2c0 5.6-8.8 10-8.8 10S3.2 14.8 3.2 9.2A4.4 4.4 0 0 1 12 8a4.4 4.4 0 0 1 8.8 1.2Z" />,
    location: (
      <>
        <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" />
        <circle cx="12" cy="10" r="2.5" />
      </>
    ),
    menu: <path d="M5 8h14M5 16h14" />,
    phone: <path d="M8.2 3.5 10 8 7.6 9.5a14 14 0 0 0 6.9 6.9L16 14l4.5 1.8-.7 4c-.1.7-.8 1.2-1.5 1.2C9.8 21 3 14.2 3 5.7c0-.7.5-1.4 1.2-1.5l4-.7Z" />,
    search: (
      <>
        <circle cx="10.8" cy="10.8" r="6.8" />
        <path d="m16 16 4.2 4.2" />
      </>
    ),
    share: (
      <>
        <circle cx="18" cy="5" r="2" />
        <circle cx="6" cy="12" r="2" />
        <circle cx="18" cy="19" r="2" />
        <path d="m8 11 8-5M8 13l8 5" />
      </>
    ),
    shield: <path d="M12 3 5 6v5c0 4.8 3 8.4 7 10 4-1.6 7-5.2 7-10V6l-7-3Zm-3 9 2 2 4-4" />,
    spark: <path d="M12 2.8 13.7 9l5.5 3-5.5 3-1.7 6.2L10.3 15l-5.5-3 5.5-3L12 2.8Z" />,
    video: (
      <>
        <rect x="3" y="6" width="13" height="12" rx="2" />
        <path d="m16 10 5-3v10l-5-3" />
      </>
    ),
  };
  return (
    <svg aria-hidden="true" className="icon" fill="none" height={size} viewBox="0 0 24 24" width={size}>
      {paths[name]}
    </svg>
  );
}

function Button({
  children,
  variant = "primary",
  icon,
  onClick,
  disabled,
  type = "button",
  className = "",
}: {
  children: ReactNode;
  variant?: "primary" | "secondary" | "quiet" | "danger";
  icon?: IconName;
  onClick?: () => void;
  disabled?: boolean;
  type?: "button" | "submit";
  className?: string;
}) {
  return (
    <button
      className={`button button--${variant} ${className}`}
      disabled={disabled}
      onClick={onClick}
      type={type}
    >
      <span>{children}</span>
      {icon && <Icon name={icon} size={18} />}
    </button>
  );
}

function Brand({ onClick }: { onClick: () => void }) {
  return (
    <button aria-label="CarePath home" className="brand" onClick={onClick} type="button">
      <span className="brand__mark"><Icon name="heart" size={18} /></span>
      <span>CarePath</span>
    </button>
  );
}

function Header({
  screen,
  onHome,
  onFindCare,
}: {
  screen: Screen;
  onHome: () => void;
  onFindCare: () => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <header className="site-header">
      <Brand onClick={onHome} />
      <nav aria-label="Main navigation" className="desktop-nav">
        <button onClick={onHome} type="button">How it works</button>
        <button onClick={onFindCare} type="button">Find care</button>
      </nav>
      <div className="header-actions">
        {screen === "home" && <Button onClick={onFindCare} variant="secondary">Find care</Button>}
        <button
          aria-expanded={menuOpen}
          aria-label={menuOpen ? "Close navigation" : "Open navigation"}
          className="menu-button"
          onClick={() => setMenuOpen(!menuOpen)}
          type="button"
        >
          <Icon name={menuOpen ? "close" : "menu"} />
        </button>
      </div>
      {menuOpen && (
        <nav aria-label="Mobile navigation" className="mobile-nav">
          <button onClick={() => { onHome(); setMenuOpen(false); }} type="button">How CarePath works</button>
          <button onClick={() => { onFindCare(); setMenuOpen(false); }} type="button">Find care</button>
        </nav>
      )}
    </header>
  );
}

function SafetyNote() {
  return (
    <aside className="safety-note">
      <Icon name="shield" size={18} />
      <p><strong>Not for emergencies.</strong> If you’re in immediate danger, call your local emergency number.</p>
    </aside>
  );
}

function Home({ onStart }: { onStart: () => void }) {
  return (
    <main>
      <section className="hero">
        <div className="hero__content">
          <div className="eyebrow eyebrow--soft"><Icon name="spark" size={15} /> Clear guidance, without the overwhelm</div>
          <h1>When you’re unsure what to do next, start here.</h1>
          <p className="hero__lead">CarePath turns a stressful health question into a calm, clear next step—one simple question at a time.</p>
          <div className="hero__actions">
            <Button icon="arrow" onClick={onStart}>Find my next step</Button>
            <span className="time-note"><Icon name="clock" size={17} /> Takes about 2 minutes</span>
          </div>
          <p className="privacy-note"><Icon name="shield" size={16} /> Private by design. No account needed.</p>
        </div>
        <div aria-label="CarePath guidance preview" className="hero-preview">
          <div className="preview-orbit preview-orbit--one" />
          <div className="preview-orbit preview-orbit--two" />
          <div className="preview-card">
            <div className="preview-card__top">
              <span className="preview-step">Your CarePath</span>
              <span className="preview-check"><Icon name="check" size={16} /></span>
            </div>
            <div className="path-line">
              <span className="path-dot path-dot--done"><Icon name="check" size={12} /></span>
              <div><strong>Tell us what’s happening</strong><span>A few simple questions</span></div>
            </div>
            <div className="path-connector" />
            <div className="path-line path-line--active">
              <span className="path-dot">2</span>
              <div><strong>See your clearest next step</strong><span>Guidance that makes sense</span></div>
            </div>
            <div className="path-connector path-connector--muted" />
            <div className="path-line path-line--muted">
              <span className="path-dot">3</span>
              <div><strong>Connect with care</strong><span>Options that fit your needs</span></div>
            </div>
          </div>
          <div className="floating-note floating-note--top"><Icon name="heart" size={17} /> Built around you</div>
          <div className="floating-note floating-note--bottom"><Icon name="shield" size={17} /> Calm, trusted guidance</div>
        </div>
      </section>

      <section className="trust-strip" aria-label="CarePath principles">
        <div><Icon name="check" /><span><strong>Plain language</strong>No confusing medical jargon</span></div>
        <div><Icon name="heart" /><span><strong>Human-centered</strong>Supportive, never alarming</span></div>
        <div><Icon name="shield" /><span><strong>Your choice</strong>You stay in control</span></div>
      </section>
    </main>
  );
}

function Intro({ onStart, onBack }: { onStart: () => void; onBack: () => void }) {
  return (
    <main className="centered-page">
      <button className="back-link" onClick={onBack} type="button"><Icon name="back" size={18} /> Back</button>
      <section className="intro-panel">
        <span className="large-icon"><Icon name="heart" size={28} /></span>
        <p className="eyebrow">Before we begin</p>
        <h1>Let’s find the right next step, together.</h1>
        <p className="intro-panel__lead">We’ll ask four short questions about what’s happening. There are no wrong answers, and you can go back at any time.</p>
        <div className="intro-points">
          <div><span><Icon name="clock" /></span><p><strong>About 2 minutes</strong><small>Move at your own pace</small></p></div>
          <div><span><Icon name="shield" /></span><p><strong>Private and secure</strong><small>Your answers stay on this device</small></p></div>
          <div><span><Icon name="heart" /></span><p><strong>Guidance, not a diagnosis</strong><small>We help you understand your options</small></p></div>
        </div>
        <Button className="button--wide" icon="arrow" onClick={onStart}>Start my CarePath</Button>
        <SafetyNote />
      </section>
    </main>
  );
}

function Assessment({
  step,
  answer,
  onSelect,
  onContinue,
  onBack,
}: {
  step: number;
  answer?: number;
  onSelect: (option: number) => void;
  onContinue: () => void;
  onBack: () => void;
}) {
  const question = questions[step];
  const progress = ((step + 1) / questions.length) * 100;
  return (
    <main className="assessment-page">
      <div className="assessment-progress" aria-label={`Question ${step + 1} of ${questions.length}`}>
        <div className="assessment-progress__meta">
          <button className="back-link" onClick={onBack} type="button"><Icon name="back" size={18} /> Back</button>
          <span>Question {step + 1} of {questions.length}</span>
        </div>
        <div aria-hidden="true" className="progress-track"><span style={{ width: `${progress}%` }} /></div>
      </div>
      <section className="question-panel">
        <p className="eyebrow">{question.eyebrow}</p>
        <h1>{question.title}</h1>
        <p className="question-helper">{question.helper}</p>
        <div aria-label={question.title} className="option-list" role="radiogroup">
          {question.options.map((option, index) => (
            <button
              aria-checked={answer === index}
              className={`option-card ${answer === index ? "option-card--selected" : ""}`}
              key={option.label}
              onClick={() => onSelect(index)}
              role="radio"
              type="button"
            >
              <span className="option-icon"><Icon name={option.icon as IconName} /></span>
              <span className="option-copy"><strong>{option.label}</strong><small>{option.detail}</small></span>
              <span className="radio-mark">{answer === index && <span />}</span>
            </button>
          ))}
        </div>
        <div className="question-actions">
          <span>Your answer helps shape your guidance.</span>
          <Button disabled={answer === undefined} icon="arrow" onClick={onContinue}>
            {step === questions.length - 1 ? "See my next step" : "Continue"}
          </Button>
        </div>
      </section>
    </main>
  );
}

function Loading() {
  return (
    <main className="state-page" aria-live="polite">
      <div className="loading-mark"><span /><Icon name="heart" size={27} /></div>
      <p className="eyebrow">Your CarePath is taking shape</p>
      <h1>Making sense of your answers…</h1>
      <p>We’re finding the clearest, safest next step for you.</p>
      <div className="loading-bar"><span /></div>
      <small>This will only take a moment</small>
    </main>
  );
}

function Result({
  onFindCare,
  onShare,
  onCareMode,
  onRestart,
}: {
  onFindCare: () => void;
  onShare: () => void;
  onCareMode: () => void;
  onRestart: () => void;
}) {
  return (
    <main className="result-page">
      <section className="result-hero">
        <div className="result-hero__copy">
          <p className="eyebrow eyebrow--light"><Icon name="check" size={15} /> Your CarePath is ready</p>
          <h1>A primary care visit is a good next step.</h1>
          <p>Based on what you shared, your concern sounds important to discuss soon, but it may not need emergency care.</p>
        </div>
        <div className="result-timing">
          <span><Icon name="clock" /></span>
          <p><small>Suggested timing</small><strong>Within the next 2–3 days</strong></p>
        </div>
      </section>

      <div className="result-grid">
        <section className="next-step-card">
          <div className="card-heading">
            <span className="number-badge">01</span>
            <div><p className="eyebrow">Your next step</p><h2>Book a primary care appointment</h2></div>
          </div>
          <p>A primary care professional can listen to your concerns, assess your symptoms, and help decide whether tests or specialist support would be useful.</p>
          <div className="reassurance"><Icon name="heart" /><span><strong>You’re doing the right thing.</strong> Reaching out now can help you get clarity sooner.</span></div>
          <div className="result-actions">
            <Button icon="arrow" onClick={onFindCare}>Find care near me</Button>
            <Button icon="phone" onClick={onCareMode} variant="secondary">Open Care Mode</Button>
          </div>
        </section>

        <aside className="result-side">
          <div className="info-card">
            <h3>What to mention at your visit</h3>
            <ul>
              <li><Icon name="check" size={16} /> When you first noticed the change</li>
              <li><Icon name="check" size={16} /> What makes it better or worse</li>
              <li><Icon name="check" size={16} /> Any medicines you’re taking</li>
            </ul>
          </div>
          <div className="watch-card">
            <span><Icon name="shield" /></span>
            <div><h3>If things change</h3><p>Seek urgent help if symptoms become severe or you feel unsafe.</p></div>
          </div>
        </aside>
      </div>

      <div className="result-footer-actions">
        <Button icon="share" onClick={onShare} variant="quiet">Share my CarePath</Button>
        <button onClick={onRestart} type="button">Start again</button>
      </div>
    </main>
  );
}

function FindCare({ onBack, onCareMode }: { onBack: () => void; onCareMode: () => void }) {
  const [query, setQuery] = useState("");
  const [locationError, setLocationError] = useState(false);
  const [mode, setMode] = useState<"all" | "in-person" | "virtual">("all");
  const filtered = providers.filter((provider) => {
    const matchesQuery = provider.name.toLowerCase().includes(query.toLowerCase());
    const matchesMode =
      mode === "all" ||
      (mode === "virtual" && provider.tags.includes("Video visit")) ||
      (mode === "in-person" && provider.tags.includes("In person"));
    return matchesQuery && matchesMode;
  });

  return (
    <main className="care-page">
      <section className="care-header">
        <button className="back-link back-link--light" onClick={onBack} type="button"><Icon name="back" size={18} /> Back to my result</button>
        <div>
          <p className="eyebrow eyebrow--light">Care that fits your next step</p>
          <h1>Find the right care, close to you.</h1>
          <p>Compare local and virtual options without the guesswork.</p>
        </div>
        <form className="care-search" onSubmit={(event) => event.preventDefault()}>
          <label>
            <span className="sr-only">Search by clinic name</span>
            <Icon name="search" />
            <input onChange={(event) => setQuery(event.target.value)} placeholder="Search by clinic name" value={query} />
          </label>
          <button onClick={() => setLocationError(true)} type="button"><Icon name="location" size={18} /> Use my location</button>
        </form>
      </section>

      <section className="provider-section">
        {locationError && (
          <div className="inline-error" role="alert">
            <Icon name="location" />
            <div><strong>We couldn’t access your location.</strong><span>That’s okay—search by clinic name, or browse the options below.</span></div>
            <button aria-label="Dismiss location message" onClick={() => setLocationError(false)} type="button"><Icon name="close" size={18} /></button>
          </div>
        )}
        <div className="provider-toolbar">
          <div><h2>Care options</h2><p>{filtered.length} options match your preferences</p></div>
          <div aria-label="Filter care options" className="segmented-control">
            {(["all", "in-person", "virtual"] as const).map((filter) => (
              <button aria-pressed={mode === filter} key={filter} onClick={() => setMode(filter)} type="button">
                {filter === "all" ? "All" : filter === "in-person" ? "In person" : "Virtual"}
              </button>
            ))}
          </div>
        </div>

        {filtered.length > 0 ? (
          <div className="provider-list">
            {filtered.map((provider, index) => (
              <article className="provider-card" key={provider.name}>
                <div className={`provider-logo provider-logo--${provider.tone}`}>{provider.initials}</div>
                <div className="provider-copy">
                  <div><p>{provider.type}</p><h3>{provider.name}</h3></div>
                  <p className="provider-meta"><Icon name={provider.tags[0] === "Video visit" ? "video" : "location"} size={17} /> {provider.meta}</p>
                  <div className="tag-row">{provider.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>
                </div>
                <div className="provider-action">
                  <Button icon="chevron" onClick={onCareMode} variant={index === 0 ? "primary" : "secondary"}>
                    {index === 0 ? "View times" : "View option"}
                  </Button>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <span><Icon name="search" size={26} /></span>
            <h3>No exact matches yet</h3>
            <p>Try a shorter clinic name or view all care types.</p>
            <Button onClick={() => { setQuery(""); setMode("all"); }} variant="secondary">Clear search and filters</Button>
          </div>
        )}
        <SafetyNote />
      </section>
    </main>
  );
}

function ShareDialog({ onClose }: { onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    dialogRef.current?.focus();
    const onKey = (event: KeyboardEvent) => event.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const copySummary = async () => {
    try {
      await navigator.clipboard.writeText("My CarePath: Book a primary care appointment within the next 2–3 days.");
    } catch {
      // The confirmation still lets the user know the summary is ready to share.
    }
    setCopied(true);
  };

  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <div aria-labelledby="share-title" aria-modal="true" className="share-dialog" onMouseDown={(event) => event.stopPropagation()} ref={dialogRef} role="dialog" tabIndex={-1}>
        <button aria-label="Close share dialog" className="dialog-close" onClick={onClose} type="button"><Icon name="close" /></button>
        <span className="large-icon"><Icon name="share" size={26} /></span>
        <p className="eyebrow">Share with someone you trust</p>
        <h2 id="share-title">Your next step, ready to share.</h2>
        <p>Send a simple summary to a family member, friend, or care professional. Your question answers are not included.</p>
        <div className="share-summary">
          <small>CarePath summary</small>
          <strong>Book a primary care appointment</strong>
          <span>Suggested within the next 2–3 days</span>
        </div>
        <Button className="button--wide" icon={copied ? "check" : "share"} onClick={copySummary}>
          {copied ? "Summary copied" : "Copy shareable summary"}
        </Button>
        <p className="dialog-privacy"><Icon name="shield" size={15} /> Only the summary above will be shared.</p>
      </div>
    </div>
  );
}

function CareMode({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState(0);
  const steps = [
    {
      label: "Before you call",
      title: "Take a breath. You know what to ask for.",
      text: "You’re looking for a primary care appointment within the next 2–3 days. Keep your calendar and any medication list nearby.",
      action: "I’m ready",
    },
    {
      label: "What to say",
      title: "Here’s a simple way to begin.",
      text: "“I have a new health concern that’s affecting my day. I’d like the soonest suitable primary care appointment.”",
      action: "Continue",
    },
    {
      label: "You’re ready",
      title: "One small step from here.",
      text: "Call Riverside Community Health. If they can’t see you soon, ask whether a virtual appointment is available.",
      action: "Call clinic",
    },
  ];
  const current = steps[step];
  return (
    <div className="care-mode" role="dialog" aria-modal="true" aria-labelledby="care-mode-title">
      <header>
        <Brand onClick={onClose} />
        <span>Care Mode</span>
        <button aria-label="Close Care Mode" onClick={onClose} type="button"><Icon name="close" /></button>
      </header>
      <main>
        <div className="care-mode__progress" aria-label={`Step ${step + 1} of ${steps.length}`}>
          {steps.map((_, index) => <span className={index <= step ? "active" : ""} key={index} />)}
        </div>
        <span className="care-mode__icon"><Icon name={step === 2 ? "phone" : "heart"} size={30} /></span>
        <p className="eyebrow">{current.label}</p>
        <h1 id="care-mode-title">{current.title}</h1>
        <p className={step === 1 ? "script-text" : ""}>{current.text}</p>
        <Button
          icon={step === 2 ? "phone" : "arrow"}
          onClick={() => step < 2 ? setStep(step + 1) : window.location.assign("tel:+15550140000")}
        >
          {current.action}
        </Button>
        {step > 0 && <button className="care-mode__back" onClick={() => setStep(step - 1)} type="button">Go back</button>}
      </main>
      <footer><Icon name="shield" size={16} /> Care Mode keeps one clear action on screen at a time.</footer>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Array<number | undefined>>([]);
  const [shareOpen, setShareOpen] = useState(false);
  const [careModeOpen, setCareModeOpen] = useState(false);

  useEffect(() => {
    if (screen !== "loading") return;
    const timer = window.setTimeout(() => setScreen("result"), 1800);
    return () => window.clearTimeout(timer);
  }, [screen]);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [screen, step]);

  const startAssessment = () => {
    setStep(0);
    setScreen("assessment");
  };

  const continueAssessment = () => {
    if (step < questions.length - 1) setStep(step + 1);
    else setScreen("loading");
  };

  const backAssessment = () => {
    if (step > 0) setStep(step - 1);
    else setScreen("intro");
  };

  const restart = () => {
    setAnswers([]);
    setStep(0);
    setScreen("home");
  };

  return (
    <div className="app-shell">
      {!careModeOpen && <Header onFindCare={() => setScreen("care")} onHome={() => setScreen("home")} screen={screen} />}
      {screen === "home" && <Home onStart={() => setScreen("intro")} />}
      {screen === "intro" && <Intro onBack={() => setScreen("home")} onStart={startAssessment} />}
      {screen === "assessment" && (
        <Assessment
          answer={answers[step]}
          onBack={backAssessment}
          onContinue={continueAssessment}
          onSelect={(option) => {
            const next = [...answers];
            next[step] = option;
            setAnswers(next);
          }}
          step={step}
        />
      )}
      {screen === "loading" && <Loading />}
      {screen === "result" && (
        <Result
          onCareMode={() => setCareModeOpen(true)}
          onFindCare={() => setScreen("care")}
          onRestart={restart}
          onShare={() => setShareOpen(true)}
        />
      )}
      {screen === "care" && <FindCare onBack={() => setScreen("result")} onCareMode={() => setCareModeOpen(true)} />}
      {shareOpen && <ShareDialog onClose={() => setShareOpen(false)} />}
      {careModeOpen && <CareMode onClose={() => setCareModeOpen(false)} />}
    </div>
  );
}
